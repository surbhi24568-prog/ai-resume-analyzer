"""
AI Resume Analyzer — Command Line Interface
Usage: python main.py <resume_file> [--json] [--save]
"""

import sys
import json
import argparse
from pathlib import Path
from datetime import datetime

# Allow running from project root
sys.path.insert(0, str(Path(__file__).parent))

from src.analyzer import analyze_resume


# ─── Terminal Colors ───────────────────────────────────────────────────────────

class Colors:
    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    RED    = "\033[91m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    BLUE   = "\033[94m"
    CYAN   = "\033[96m"
    WHITE  = "\033[97m"
    GRAY   = "\033[90m"


def colorize(text, color):
    return f"{color}{text}{Colors.RESET}"


def grade_color(grade):
    return {
        "A": Colors.GREEN,
        "B": Colors.CYAN,
        "C": Colors.YELLOW,
        "D": Colors.YELLOW,
        "F": Colors.RED,
    }.get(grade, Colors.WHITE)


# ─── Display Functions ─────────────────────────────────────────────────────────

def print_banner():
    banner = r"""
  ____  _____ ____  _   _ __  __ _____      _    _   _    _    _   __   _______ _____ ____
 |  _ \| ____/ ___|| | | |  \/  | ____|    / \  | \ | |  / \  | |  \ \ / /__  /| ____|  _ \
 | |_) |  _| \___ \| | | | |\/| |  _|     / _ \ |  \| | / _ \ | |   \ V /  / / |  _| | |_) |
 |  _ <| |___ ___) | |_| | |  | | |___   / ___ \| |\  |/ ___ \| |___ | |  / /_ | |___|  _ <
 |_| \_\_____|____/ \___/|_|  |_|_____| /_/   \_\_| \_/_/   \_\_____|_| /____|_|_____|_| \_\
    """
    print(colorize(banner, Colors.CYAN))
    print(colorize("           🤖  AI-Powered Resume Analyzer  |  v1.0.0\n", Colors.GRAY))


def print_section(title):
    width = 60
    print(f"\n{colorize('─' * width, Colors.GRAY)}")
    print(colorize(f"  {title}", Colors.BOLD + Colors.WHITE))
    print(colorize('─' * width, Colors.GRAY))


def print_score_bar(label, score, max_score):
    filled = int((score / max_score) * 20)
    bar = "█" * filled + "░" * (20 - filled)
    color = Colors.GREEN if score / max_score >= 0.7 else Colors.YELLOW if score / max_score >= 0.4 else Colors.RED
    print(f"  {label:<28} {colorize(bar, color)}  {score}/{max_score}")


def print_report(result: dict):
    print_banner()

    # ── Contact Info ──
    print_section("📋 CONTACT INFORMATION")
    contact = result["contact_info"]
    for key, val in contact.items():
        label = key.replace("_", " ").title()
        value = val if val else colorize("Not found", Colors.YELLOW)
        print(f"  {label:<12}: {value}")

    # ── Sections ──
    print_section("📑 SECTIONS DETECTED")
    for section, found in result["sections_detected"].items():
        icon  = colorize("✔", Colors.GREEN) if found else colorize("✘", Colors.RED)
        label = section.replace("_", " ").title()
        print(f"  {icon}  {label}")

    # ── Skills ──
    print_section("🛠️  SKILLS FOUND")
    skills = result["skills"]
    if skills:
        for category, skill_list in skills.items():
            cat_label = category.replace("_", " ").title()
            skills_str = ", ".join(skill_list)
            print(f"  {colorize(cat_label + ':', Colors.CYAN)} {skills_str}")
    else:
        print(colorize("  No recognizable skills found.", Colors.YELLOW))

    # ── Quick Stats ──
    print_section("📊 QUICK STATS")
    print(f"  {'Word Count':<30}: {result['word_count']}")
    print(f"  {'Estimated Experience':<30}: {result['estimated_years_experience']} year(s)")
    print(f"  {'Quantified Achievements':<30}: {result['quantified_achievements']}")
    print(f"  {'Strong Action Verbs Used':<30}: {len(result['action_verbs'])}")
    if result["action_verbs"]:
        print(f"    {colorize('→ ' + ', '.join(result['action_verbs']), Colors.GRAY)}")

    # ── Score Breakdown ──
    print_section("🏆 SCORE BREAKDOWN")
    breakdown = result["score"]["breakdown"]
    max_scores = {
        "contact_info":            20,
        "sections":                20,
        "skills":                  25,
        "action_verbs":            15,
        "quantified_achievements": 20,
    }
    for key, max_val in max_scores.items():
        label = key.replace("_", " ").title()
        print_score_bar(label, breakdown.get(key, 0), max_val)

    total = result["score"]["total"]
    grade = result["score"]["grade"]
    g_color = grade_color(grade)
    print(f"\n  {'TOTAL SCORE':<28} {colorize(str(total) + '/100', Colors.BOLD)}  "
          f"Grade: {colorize(grade, g_color + Colors.BOLD)}")

    # ── Suggestions ──
    print_section("💡 IMPROVEMENT SUGGESTIONS")
    for tip in result["suggestions"]:
        print(f"  {tip}")

    print(f"\n{colorize('─' * 60, Colors.GRAY)}\n")


# ─── Entry Point ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="AI Resume Analyzer — analyze your resume and get actionable feedback."
    )
    parser.add_argument("file", help="Path to resume file (PDF, DOCX, or TXT)")
    parser.add_argument("--json",  action="store_true", help="Output raw JSON instead of formatted report")
    parser.add_argument("--save",  action="store_true", help="Save the JSON report to ./outputs/")
    args = parser.parse_args()

    try:
        result = analyze_resume(args.file)

        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print_report(result)

        if args.save:
            Path("outputs").mkdir(exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            out_file  = f"outputs/report_{timestamp}.json"
            with open(out_file, "w") as f:
                json.dump(result, f, indent=2)
            print(f"  📁 Report saved to: {out_file}\n")

    except FileNotFoundError:
        print(colorize(f"\n  ❌ File not found: {args.file}\n", Colors.RED))
        sys.exit(1)
    except ValueError as e:
        print(colorize(f"\n  ❌ {e}\n", Colors.RED))
        sys.exit(1)
    except ImportError as e:
        print(colorize(f"\n  ⚠️  Missing dependency: {e}\n", Colors.YELLOW))
        sys.exit(1)


if __name__ == "__main__":
    main()
