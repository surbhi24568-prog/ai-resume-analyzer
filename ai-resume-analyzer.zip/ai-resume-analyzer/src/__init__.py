# AI Resume Analyzer - Source Package
from .analyzer import analyze_resume

__all__ = ["analyze_resume"]
