"""
AI Resume Analyzer - Core Analysis Engine
Analyzes resumes using NLP and keyword matching techniques.
"""

import re
import json
from pathlib import Path
from collections import Counter
from typing import Optional

try:
    import pdfplumber
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False

try:
    from docx import Document
    DOCX_SUPPORT = True
except ImportError:
    DOCX_SUPPORT = False


# ─── Skill Taxonomy ────────────────────────────────────────────────────────────

SKILLS_DB = {
    "programming_languages": [
        "python", "java", "javascript", "typescript", "c++", "c#", "go", "rust",
        "kotlin", "swift", "ruby", "php", "scala", "r", "matlab", "dart"
    ],
    "web_frameworks": [
        "react", "angular", "vue", "django", "flask", "fastapi", "spring",
        "express", "nextjs", "nuxt", "laravel", "rails", "asp.net"
    ],
    "databases": [
        "mysql", "postgresql", "mongodb", "redis", "sqlite", "oracle",
        "cassandra", "dynamodb", "firebase", "elasticsearch"
    ],
    "cloud_devops": [
        "aws", "azure", "gcp", "docker", "kubernetes", "terraform", "jenkins",
        "github actions", "ci/cd", "ansible", "linux", "bash"
    ],
    "data_ml": [
        "machine learning", "deep learning", "tensorflow", "pytorch", "scikit-learn",
        "pandas", "numpy", "tableau", "power bi", "spark", "hadoop", "nlp",
        "computer vision", "data analysis", "statistics"
    ],
    "soft_skills": [
        "leadership", "communication", "teamwork", "problem solving", "agile",
        "scrum", "project management", "time management", "collaboration",
        "critical thinking", "adaptability", "mentoring"
    ]
}

ACTION_VERBS = [
    "developed", "built", "designed", "implemented", "led", "managed",
    "created", "improved", "optimized", "deployed", "architected", "launched",
    "delivered", "collaborated", "mentored", "automated", "reduced", "increased",
    "established", "maintained", "analyzed", "researched", "presented"
]

SECTION_KEYWORDS = {
    "education":    ["education", "academic", "university", "college", "degree", "bachelor", "master", "phd"],
    "experience":   ["experience", "work history", "employment", "professional background", "career"],
    "skills":       ["skills", "technical skills", "competencies", "technologies", "tools"],
    "projects":     ["projects", "personal projects", "open source", "portfolio"],
    "certifications": ["certifications", "certificates", "credentials", "licenses"],
    "summary":      ["summary", "objective", "profile", "about me", "overview"]
}


# ─── Text Extraction ───────────────────────────────────────────────────────────

def extract_text(file_path: str) -> str:
    """Extract text from PDF, DOCX, or plain text files."""
    path = Path(file_path)
    suffix = path.suffix.lower()

    if suffix == ".pdf":
        if not PDF_SUPPORT:
            raise ImportError("pdfplumber not installed. Run: pip install pdfplumber")
        with pdfplumber.open(file_path) as pdf:
            return "\n".join(page.extract_text() or "" for page in pdf.pages)

    elif suffix == ".docx":
        if not DOCX_SUPPORT:
            raise ImportError("python-docx not installed. Run: pip install python-docx")
        doc = Document(file_path)
        return "\n".join(p.text for p in doc.paragraphs)

    elif suffix in [".txt", ".text"]:
        return path.read_text(encoding="utf-8")

    else:
        raise ValueError(f"Unsupported file type: {suffix}. Use PDF, DOCX, or TXT.")


# ─── Parsing Helpers ───────────────────────────────────────────────────────────

def extract_email(text: str) -> Optional[str]:
    match = re.search(r"[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}", text)
    return match.group(0) if match else None


def extract_phone(text: str) -> Optional[str]:
    match = re.search(r"(\+?\d[\d\s\-().]{7,}\d)", text)
    return match.group(0).strip() if match else None


def extract_name(text: str) -> Optional[str]:
    """Heuristic: the name is usually the first non-empty line."""
    lines = [l.strip() for l in text.strip().splitlines() if l.strip()]
    if lines:
        first = lines[0]
        # Likely a name if it's short and has no digits
        if len(first.split()) <= 5 and not re.search(r"\d", first):
            return first
    return None


def extract_linkedin(text: str) -> Optional[str]:
    match = re.search(r"linkedin\.com/in/[\w-]+", text, re.IGNORECASE)
    return "https://" + match.group(0) if match else None


def extract_github(text: str) -> Optional[str]:
    match = re.search(r"github\.com/[\w-]+", text, re.IGNORECASE)
    return "https://" + match.group(0) if match else None


def detect_sections(text: str) -> dict:
    """Identify which resume sections are present."""
    found = {}
    lower = text.lower()
    for section, keywords in SECTION_KEYWORDS.items():
        found[section] = any(kw in lower for kw in keywords)
    return found


def extract_skills(text: str) -> dict:
    """Extract skills grouped by category."""
    lower = text.lower()
    found = {}
    for category, skills in SKILLS_DB.items():
        matched = [s for s in skills if re.search(r"\b" + re.escape(s) + r"\b", lower)]
        if matched:
            found[category] = matched
    return found


def extract_action_verbs(text: str) -> list:
    """Find strong action verbs used in bullet points."""
    lower = text.lower()
    return [v for v in ACTION_VERBS if re.search(r"\b" + v + r"\b", lower)]


def count_quantified_achievements(text: str) -> int:
    """Count bullet points that contain numbers (quantified impact)."""
    pattern = r"[\•\-\*]\s*.*?\d+.*"
    return len(re.findall(pattern, text))


def estimate_years_experience(text: str) -> int:
    """Rough estimate of total years from date ranges."""
    years = re.findall(r"\b(19|20)\d{2}\b", text)
    if len(years) >= 2:
        years_int = sorted(set(int(y) for y in years))
        return years_int[-1] - years_int[0]
    return 0


# ─── Scoring Engine ────────────────────────────────────────────────────────────

def score_resume(text: str, skills: dict, sections: dict, action_verbs: list,
                  quantified: int, contact_info: dict) -> dict:
    scores = {}

    # Contact completeness (20 pts)
    contact_score = sum([
        bool(contact_info.get("email")) * 7,
        bool(contact_info.get("phone")) * 5,
        bool(contact_info.get("linkedin")) * 4,
        bool(contact_info.get("github")) * 4,
    ])
    scores["contact_info"] = min(contact_score, 20)

    # Sections (20 pts)
    important = ["experience", "education", "skills", "summary"]
    section_score = sum(8 if s == "experience" else 4 for s in important if sections.get(s))
    scores["sections"] = min(section_score, 20)

    # Skills breadth (25 pts)
    total_skills = sum(len(v) for v in skills.values())
    scores["skills"] = min(total_skills * 2, 25)

    # Action verbs (15 pts)
    scores["action_verbs"] = min(len(action_verbs) * 2, 15)

    # Quantified achievements (20 pts)
    scores["quantified_achievements"] = min(quantified * 4, 20)

    total = sum(scores.values())
    return {"breakdown": scores, "total": total, "grade": _grade(total)}


def _grade(score: int) -> str:
    if score >= 85: return "A"
    if score >= 70: return "B"
    if score >= 55: return "C"
    if score >= 40: return "D"
    return "F"


# ─── Suggestion Engine ─────────────────────────────────────────────────────────

def generate_suggestions(sections: dict, skills: dict, action_verbs: list,
                           quantified: int, contact_info: dict) -> list:
    tips = []

    if not contact_info.get("email"):
        tips.append("❌ Add your email address — recruiters need a way to reach you.")
    if not contact_info.get("linkedin"):
        tips.append("💼 Add your LinkedIn profile URL to boost credibility.")
    if not contact_info.get("github") and "programming_languages" in skills:
        tips.append("🐙 Add your GitHub profile to showcase your code.")

    if not sections.get("summary"):
        tips.append("📝 Add a professional summary/objective at the top (3–4 lines).")
    if not sections.get("projects"):
        tips.append("🚀 Include a Projects section — it's highly valued for tech roles.")
    if not sections.get("certifications"):
        tips.append("🏆 Consider adding certifications (AWS, Google, etc.) to stand out.")

    if len(action_verbs) < 5:
        tips.append("💪 Use more strong action verbs: 'Built', 'Led', 'Optimized', 'Deployed'.")
    if quantified < 3:
        tips.append("📊 Quantify your achievements: '↑ performance by 40%', 'managed 5-person team'.")
    if not skills.get("cloud_devops"):
        tips.append("☁️  Add cloud/DevOps skills (AWS, Docker, CI/CD) — in high demand.")
    if not skills.get("data_ml") and not skills.get("web_frameworks"):
        tips.append("🔧 Expand your technical skills section with frameworks or tools you know.")

    if not tips:
        tips.append("✅ Your resume looks solid! Keep it updated with latest projects.")

    return tips


# ─── Main Analysis Function ────────────────────────────────────────────────────

def analyze_resume(file_path: str) -> dict:
    """Full pipeline: extract → parse → score → suggest."""
    print(f"📄 Analyzing: {file_path}")

    text = extract_text(file_path)

    contact_info = {
        "name":     extract_name(text),
        "email":    extract_email(text),
        "phone":    extract_phone(text),
        "linkedin": extract_linkedin(text),
        "github":   extract_github(text),
    }

    sections       = detect_sections(text)
    skills         = extract_skills(text)
    action_verbs   = extract_action_verbs(text)
    quantified     = count_quantified_achievements(text)
    years_exp      = estimate_years_experience(text)
    word_count     = len(text.split())

    scoring = score_resume(text, skills, sections, action_verbs, quantified, contact_info)
    suggestions = generate_suggestions(sections, skills, action_verbs, quantified, contact_info)

    return {
        "file":              file_path,
        "contact_info":      contact_info,
        "sections_detected": sections,
        "skills":            skills,
        "action_verbs":      action_verbs,
        "quantified_achievements": quantified,
        "estimated_years_experience": years_exp,
        "word_count":        word_count,
        "score":             scoring,
        "suggestions":       suggestions,
    }
