# 🤖 AI Resume Analyzer

A Python command-line tool that analyzes resumes and gives actionable, scored feedback — no paid APIs needed, runs entirely offline.

![Python](https://img.shields.io/badge/Python-3.8%2B-blue?logo=python)
![License](https://img.shields.io/badge/License-MIT-green)
![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen)

---

## ✨ Features

- 📄 **Multi-format support** — PDF, DOCX, and plain TXT resumes
- 📋 **Contact extraction** — Name, email, phone, LinkedIn, GitHub
- 🛠️ **Skill detection** — 6 categories: languages, frameworks, databases, cloud, ML, soft skills
- 📑 **Section audit** — Checks for summary, experience, education, projects, certifications
- 💪 **Action verb analysis** — Flags weak language and suggests stronger alternatives
- 📊 **Quantified impact scoring** — Rewards bullet points backed by numbers
- 🏆 **100-point scoring system** with letter grade (A–F)
- 💡 **Targeted suggestions** — Specific, actionable tips based on what's missing
- 💾 **JSON export** — Save results for further processing or integration

---

## 📁 Project Structure

```
ai-resume-analyzer/
│
├── src/
│   ├── __init__.py
│   └── analyzer.py        # Core analysis engine
│
├── tests/
│   ├── __init__.py
│   └── test_analyzer.py   # Unit tests (pytest)
│
├── sample_resumes/
│   └── sample_resume.txt  # Demo resume to try out
│
├── outputs/               # Saved JSON reports (auto-created)
│
├── main.py                # CLI entry point
├── requirements.txt
└── README.md
```

---

## 🚀 Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/ai-resume-analyzer.git
cd ai-resume-analyzer
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

> **Note:** The tool works with `.txt` files out of the box. PDF support requires `pdfplumber`, and DOCX support requires `python-docx` — both are in `requirements.txt`.

### 3. Run on the sample resume

```bash
python main.py sample_resumes/sample_resume.txt
```

### 4. Run on your own resume

```bash
python main.py /path/to/your/resume.pdf
```

---

## 🖥️ CLI Usage

```
python main.py <file> [options]

Arguments:
  file              Path to your resume (PDF, DOCX, or TXT)

Options:
  --json            Output raw JSON instead of formatted report
  --save            Save JSON report to ./outputs/
  -h, --help        Show this help message
```

### Examples

```bash
# Basic analysis with color report
python main.py my_resume.pdf

# Export as JSON
python main.py my_resume.docx --json

# Save report to file
python main.py my_resume.txt --save

# Both JSON output and save
python main.py my_resume.pdf --json --save
```

---

## 📊 Scoring Breakdown

| Category                  | Max Points | How to Maximize                              |
|---------------------------|:----------:|----------------------------------------------|
| Contact Information       | 20         | Email, phone, LinkedIn, GitHub               |
| Sections Present          | 20         | Experience, education, skills, summary       |
| Skills Breadth            | 25         | Across multiple technology categories        |
| Action Verbs              | 15         | Built, Led, Optimized, Deployed, etc.        |
| Quantified Achievements   | 20         | Numbers in bullet points (%, $, users, etc.) |
| **Total**                 | **100**    |                                              |

### Grading Scale

| Grade | Score |
|-------|-------|
| A     | 85–100 |
| B     | 70–84  |
| C     | 55–69  |
| D     | 40–54  |
| F     | 0–39   |

---

## 🧪 Running Tests

```bash
pytest tests/test_analyzer.py -v
```

The test suite covers: contact extraction, section detection, skill parsing, action verb detection, achievement quantification, scoring, and suggestions.

---

## 🔧 How It Works

The analyzer runs a pipeline on your resume text:

```
Resume File
    │
    ▼
Text Extraction  (pdfplumber / python-docx / plain text)
    │
    ▼
NLP Parsing      (regex + keyword matching)
    │
    ├── Contact Info
    ├── Section Detection
    ├── Skill Taxonomy Matching
    ├── Action Verb Scan
    └── Quantified Achievement Count
    │
    ▼
Scoring Engine   (weighted 100-point scale)
    │
    ▼
Suggestion Engine (rule-based gap analysis)
    │
    ▼
Formatted Report / JSON Output
```

---

## 🛣️ Roadmap

- [ ] Job description matching (compare resume vs JD)
- [ ] AI-powered rewrite suggestions using LLM APIs
- [ ] Web interface (Flask / Streamlit)
- [ ] ATS (Applicant Tracking System) keyword simulation
- [ ] Support for multiple languages

---

## 🤝 Contributing

Contributions are welcome! Here's how:

1. Fork the repo
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit changes: `git commit -m "Add my feature"`
4. Push: `git push origin feature/my-feature`
5. Open a Pull Request

Please add/update tests for any new functionality.

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).

---

## ⭐ Show Your Support

If this project helped you, please consider giving it a ⭐ on GitHub!
