"""
Unit Tests for AI Resume Analyzer
Run with: pytest tests/test_analyzer.py -v
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.analyzer import (
    extract_email, extract_phone, extract_name, extract_linkedin,
    extract_github, detect_sections, extract_skills, extract_action_verbs,
    count_quantified_achievements, score_resume, generate_suggestions
)


# ─── Sample Resume Text ────────────────────────────────────────────────────────

SAMPLE_RESUME = """
John Doe
john.doe@email.com | +1-555-123-4567 | linkedin.com/in/johndoe | github.com/johndoe

SUMMARY
Passionate software engineer with 4 years of experience building scalable web apps.

EXPERIENCE
Software Engineer | TechCorp | 2021 – 2024
- Developed and deployed microservices using Python and Docker
- Optimized database queries, reducing load time by 40%
- Led a team of 5 engineers to deliver a new product feature
- Built CI/CD pipelines using GitHub Actions

EDUCATION
Bachelor of Science in Computer Science | MIT | 2017 – 2021

SKILLS
Python, JavaScript, React, PostgreSQL, AWS, Docker, Kubernetes, Machine Learning

PROJECTS
- Built an open-source CLI tool with 200+ GitHub stars
- Implemented a deep learning model for image classification with 93% accuracy

CERTIFICATIONS
AWS Certified Solutions Architect
"""

MINIMAL_RESUME = """
Jane Smith
No skills or contact info here. Just some text about working at a company.
"""


# ─── Contact Extraction Tests ─────────────────────────────────────────────────

class TestContactExtraction:
    def test_email_found(self):
        assert extract_email(SAMPLE_RESUME) == "john.doe@email.com"

    def test_email_not_found(self):
        assert extract_email("No email here.") is None

    def test_phone_found(self):
        phone = extract_phone(SAMPLE_RESUME)
        assert phone is not None
        assert "555" in phone

    def test_name_extracted(self):
        name = extract_name(SAMPLE_RESUME)
        assert name == "John Doe"

    def test_linkedin_found(self):
        url = extract_linkedin(SAMPLE_RESUME)
        assert url == "https://linkedin.com/in/johndoe"

    def test_github_found(self):
        url = extract_github(SAMPLE_RESUME)
        assert url == "https://github.com/johndoe"


# ─── Section Detection Tests ──────────────────────────────────────────────────

class TestSectionDetection:
    def test_detects_experience(self):
        sections = detect_sections(SAMPLE_RESUME)
        assert sections["experience"] is True

    def test_detects_education(self):
        sections = detect_sections(SAMPLE_RESUME)
        assert sections["education"] is True

    def test_detects_skills(self):
        sections = detect_sections(SAMPLE_RESUME)
        assert sections["skills"] is True

    def test_detects_summary(self):
        sections = detect_sections(SAMPLE_RESUME)
        assert sections["summary"] is True

    def test_detects_certifications(self):
        sections = detect_sections(SAMPLE_RESUME)
        assert sections["certifications"] is True

    def test_missing_section_in_minimal(self):
        sections = detect_sections(MINIMAL_RESUME)
        assert sections["certifications"] is False


# ─── Skills Extraction Tests ──────────────────────────────────────────────────

class TestSkillsExtraction:
    def test_programming_languages(self):
        skills = extract_skills(SAMPLE_RESUME)
        assert "programming_languages" in skills
        assert "python" in skills["programming_languages"]
        assert "javascript" in skills["programming_languages"]

    def test_web_frameworks(self):
        skills = extract_skills(SAMPLE_RESUME)
        assert "web_frameworks" in skills
        assert "react" in skills["web_frameworks"]

    def test_cloud_devops(self):
        skills = extract_skills(SAMPLE_RESUME)
        assert "cloud_devops" in skills
        assert "aws" in skills["cloud_devops"]
        assert "docker" in skills["cloud_devops"]

    def test_no_skills_in_minimal(self):
        skills = extract_skills(MINIMAL_RESUME)
        assert len(skills) == 0


# ─── Action Verbs Tests ───────────────────────────────────────────────────────

class TestActionVerbs:
    def test_action_verbs_found(self):
        verbs = extract_action_verbs(SAMPLE_RESUME)
        assert len(verbs) >= 3
        assert "developed" in verbs
        assert "built" in verbs

    def test_no_verbs_in_minimal(self):
        verbs = extract_action_verbs(MINIMAL_RESUME)
        assert len(verbs) == 0


# ─── Quantification Tests ─────────────────────────────────────────────────────

class TestQuantification:
    def test_counts_bullets_with_numbers(self):
        count = count_quantified_achievements(SAMPLE_RESUME)
        assert count >= 2  # "40%", "5 engineers", "200+", "93%"

    def test_zero_for_no_bullets(self):
        count = count_quantified_achievements("No bullet points here.")
        assert count == 0


# ─── Scoring Tests ────────────────────────────────────────────────────────────

class TestScoring:
    def setup_method(self):
        contact = {
            "email": "test@test.com", "phone": "123",
            "linkedin": "url", "github": "url"
        }
        skills   = extract_skills(SAMPLE_RESUME)
        sections = detect_sections(SAMPLE_RESUME)
        verbs    = extract_action_verbs(SAMPLE_RESUME)
        quant    = count_quantified_achievements(SAMPLE_RESUME)
        self.result = score_resume(SAMPLE_RESUME, skills, sections, verbs, quant, contact)

    def test_total_in_range(self):
        assert 0 <= self.result["total"] <= 100

    def test_grade_assigned(self):
        assert self.result["grade"] in ["A", "B", "C", "D", "F"]

    def test_strong_resume_scores_well(self):
        assert self.result["total"] >= 60

    def test_breakdown_has_all_keys(self):
        keys = {"contact_info", "sections", "skills", "action_verbs", "quantified_achievements"}
        assert keys.issubset(set(self.result["breakdown"].keys()))


# ─── Suggestion Tests ─────────────────────────────────────────────────────────

class TestSuggestions:
    def test_missing_email_triggers_tip(self):
        contact  = {"email": None, "phone": None, "linkedin": None, "github": None}
        sections = {k: False for k in ["education", "experience", "skills", "summary", "projects", "certifications"]}
        tips = generate_suggestions(sections, {}, [], 0, contact)
        assert any("email" in t.lower() for t in tips)

    def test_missing_summary_triggers_tip(self):
        contact  = {"email": "x@x.com", "phone": "1", "linkedin": "url", "github": None}
        sections = {k: True for k in ["education", "experience", "skills"]}
        sections["summary"]  = False
        sections["projects"] = False
        sections["certifications"] = False
        tips = generate_suggestions(sections, {"programming_languages": ["python"]}, ["built"], 5, contact)
        assert any("summary" in t.lower() for t in tips)
